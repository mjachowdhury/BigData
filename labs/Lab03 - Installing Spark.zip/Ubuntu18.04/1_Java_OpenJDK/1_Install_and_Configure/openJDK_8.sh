#!/bin/bash 
sudo apt-get update
sudo apt-get install openjdk-8-jdk
sudo update-alternatives --config java
sudo update-alternatives --config javac 
sudo gedit ~/.bashrc

